"""
Navigator Agent
---------------
Finds the safest route and nearest available shelter for a citizen.

Input : location (dict: lat, lng), road_status (dict)
Output: { "shelter": dict, "distance_km": float, "route": list }
"""


def find_shelter(location: dict, road_status: dict) -> dict:
    # TODO: implement shelter lookup + routing logic
    raise NotImplementedError
