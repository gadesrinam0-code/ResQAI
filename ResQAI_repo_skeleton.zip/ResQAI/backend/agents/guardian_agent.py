"""
Guardian Agent
--------------
Talks to the citizen and extracts structured details from their emergency
report (text or voice input).

Input : raw_report (dict) -- name, phone, location, description, disaster_type
Output: { "emergency_id": str, "structured_data": dict }
"""


def structure_report(raw_report: dict) -> dict:
    # TODO: implement NLP extraction / voice transcription handling
    raise NotImplementedError
