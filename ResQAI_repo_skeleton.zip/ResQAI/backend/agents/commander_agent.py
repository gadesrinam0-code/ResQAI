"""
Commander Agent
---------------
Combines the outputs of MedicAI, Navigator, SupplyMind, and VolunteerSync
into one explained rescue plan with a 0-100 risk score.

Input : medic_result (dict), navigator_result (dict),
        supplymind_result (dict), volunteersync_result (dict)
Output: { "rescue_plan": dict, "risk_score": int, "reasoning": str }
"""


def generate_plan(medic_result: dict, navigator_result: dict,
                   supplymind_result: dict, volunteersync_result: dict) -> dict:
    # TODO: implement synthesis + risk scoring + reasoning generation
    raise NotImplementedError
