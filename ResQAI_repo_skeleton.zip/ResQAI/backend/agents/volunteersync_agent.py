"""
VolunteerSync Agent
--------------------
Matches and assigns nearby available volunteers to an incident.

Input : location (dict), volunteer_registry (list)
Output: { "volunteers_assigned": list }
"""


def assign_volunteers(location: dict, volunteer_registry: list) -> dict:
    # TODO: implement volunteer matching logic
    raise NotImplementedError
