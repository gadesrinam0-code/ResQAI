"""
API routes for ResQAI.

POST /report            -> submit a new emergency report, kicks off the agent pipeline
GET  /status/{report_id} -> poll processing status / final rescue plan
GET  /dashboard          -> aggregated data for the Command Center
GET  /dashboard/predict   -> simulated 6-hour prediction panel
POST /dashboard/whatif    -> simulated what-if recalculation
"""

from fastapi import APIRouter

router = APIRouter()

# TODO: wire these up to the agent pipeline in backend/agents/
