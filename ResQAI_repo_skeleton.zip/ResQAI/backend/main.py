"""
ResQAI backend entrypoint (FastAPI).
"""

from fastapi import FastAPI
from api.routes import router

app = FastAPI(title="ResQAI - Autonomous Disaster Intelligence Network")
app.include_router(router)


@app.get("/health")
def health():
    return {"status": "ok"}
