"""
Database models for ResQAI (SQLAlchemy / Pydantic).

TODO: define EmergencyReport, Shelter, ResourceTeam, Volunteer, Incident models.
"""
