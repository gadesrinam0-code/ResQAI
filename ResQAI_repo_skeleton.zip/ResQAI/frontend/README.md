# ResQAI Frontend

React + Tailwind + Leaflet frontend for the ResQAI Command Center.

## Pages
- Home
- Emergency Report Form
- Agent Collaboration Timeline
- Rescue Plan Result
- Command Center Dashboard
- Mission Summary

## Setup
```bash
npm install
npm run dev
```
