# ResQAI — Demo Video Script (2:30–3:00)

**Format:** screen recording + voiceover. Record the voiceover separately if
that's easier to get clean audio, then sync it in editing.

---

## 0:00–0:20 — The Hook

**Visual:** black screen or a slow zoom on a flood/disaster stock image, then cut to the ResQAI logo/home screen.

**Voiceover:**
> "It's 2:15 AM. A cyclone has hit Visakhapatnam. Roads are flooded, and
> hundreds of emergency calls arrive every minute — more than any human
> dispatch team can process. This is ResQAI: an Autonomous Disaster
> Intelligence Network where AI agents collaborate to save lives."

---

## 0:20–0:40 — Home Page

**Visual:** Home screen — Report Emergency button, nearest shelters, active incidents.

**Voiceover:**
> "Citizens report an emergency in seconds — location, disaster type, and a
> description, in English, Telugu, or Hindi."

---

## 0:40–1:10 — Submit an Emergency

**Visual:** Fill out the Report Emergency form live.

**Example data to use:**
- Name: Rahul
- Disaster: Flood
- People affected: 4 (including 2 children)
- Location: Patamata, Vijayawada

**Action:** Click **Submit Report**.

**Voiceover:**
> "Rahul reports a flood at his home in Patamata — four people, including
> two children. The moment he submits, ResQAI's agents take over."

---

## 1:10–1:50 — Agents at Work

**Visual:** Agent Collaboration Timeline screen, showing each line appear in sequence.

```
00:00  Citizen report received
00:02  Guardian extracted location + details
00:04  Sentinel verified flood severity: HIGH
00:05  MedicAI: HIGH priority (children present)
00:06  Navigator: shelter found, 2.4 km away
00:07  SupplyMind: Boat Team-2 assigned
00:08  Commander: rescue plan approved
```

**Voiceover:**
> "Guardian structures the report. Sentinel verifies the flood's severity
> against live conditions. Then MedicAI, Navigator, SupplyMind, and
> VolunteerSync work in parallel — triaging urgency, finding a shelter,
> and assigning a rescue team. Commander brings it all together into one
> decision, in under ten seconds."

---

## 1:50–2:30 — Rescue Plan (Explainable AI)

**Visual:** Rescue Plan result screen — risk score breakdown, shelter, decision + reasoning.

```
Risk Score: 92 / 100        Priority: CRITICAL

Flood Depth 40%  Medical 30%  Children 15%  Weather 10%  Road 5%

Shelter: ZPHS Community Hall, Patamata — 1.2 km

Decision: Deploy Boat Team-3
Reason: Flood depth exceeds 4 ft. Two children detected.
        Road inaccessible. Shelter available nearby.
```

**Voiceover:**
> "This isn't a black box. ResQAI shows exactly why it made this call — a
> risk score built from flood depth, medical need, and road conditions —
> so responders can trust and act on it immediately."

---

## 2:30–3:00 — Command Center + Close

**Visual:** Command Center dashboard — live map, incident queue, weather alert, what-if panel, then Mission Summary screen.

**Voiceover:**
> "Every incident, resource, and agent decision is visible live on the
> Command Center — the way a real emergency operations center would run
> it. Across one mission, ResQAI handled 47 requests, helped rescue 132
> people, with an average response time of 4.2 minutes.
>
> ResQAI shows how agentic AI can coordinate disaster response, optimize
> resources, and make emergency decisions faster, together, and
> transparently."

**End card:** ResQAI logo + tagline — *"When every second matters, AI agents work together to save lives."*

---

## Recording Checklist

- [ ] Screen resolution set to 1920x1080 before recording
- [ ] Close unrelated browser tabs/notifications
- [ ] Use the exact example data above so numbers in the voiceover match the screen
- [ ] Record voiceover in a quiet room; do 2 takes and pick the cleaner one
- [ ] Keep total runtime under 3:00 (aim for 2:45)
- [ ] Export as MP4, upload to `demo/` folder and/or the submission platform
