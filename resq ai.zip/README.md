# ResQAI — Autonomous Disaster Intelligence Network (ADIN)

> "When every second matters, AI agents work together to save lives."

ResQAI is a multi-agent AI command center for disaster response coordination.
Seven specialized agents detect, triage, route, allocate resources, and
decide — collaboratively and transparently — turning a flood of emergency
reports into a prioritized, explained rescue plan in seconds.

Built for the BRAVE Agentic AI Hackathon (Social Impact track).

---

## Problem Statement

During disasters (floods, cyclones, fires, building collapses), the biggest
loss of time isn't response capacity — it's coordination. Citizens don't know
who to report to, responders lack structured, prioritized information, and
resource allocation is done manually over phone and radio. ResQAI closes that
gap with a coordinated team of AI agents and a live command center.

Full write-up: [`docs/Problem_Statement.pdf`](docs/Problem_Statement.pdf)

---

## Features

- **Citizen reporting** — emergency report form with location, disaster type,
  photo attachment, and voice input (EN / TE / HI — simulated for demo)
- **Agent Collaboration Timeline** — watch the AI agents work in real time
- **Explainable Rescue Plans** — risk score (0–100) with a scored breakdown
  and a plain-language reason for every decision
- **Command Center Dashboard** — live incident queue, disaster map, agent
  activity panel, weather alerts, shelter occupancy, resource inventory
- **What-if Simulation** *(simulated)* — see how changing conditions (e.g.
  rainfall) shifts flood risk and resource needs
- **6-Hour Prediction** *(simulated)* — proactive forecast of incoming
  emergencies and resources needed
- **Mission Summary** — end-of-session stats: requests handled, people
  rescued, response time, AI decisions made

---

## AI Agent Architecture

| Agent | Role | Responsibility |
|---|---|---|
| **Sentinel** | Detection | Detects & verifies disaster severity from weather/news/citizen reports |
| **Guardian** | Intake | Talks to citizens, structures their emergency report |
| **MedicAI** | Medical Triage | Assesses medical urgency and priority |
| **Navigator** | Routing | Finds the safest route and nearest shelter |
| **SupplyMind** | Resources | Allocates boats, ambulances, food, medical kits |
| **VolunteerSync** | Volunteers | Matches nearby volunteers to the incident |
| **Commander** | Decision | Synthesizes everything into one explained rescue plan + risk score |

Guardian and Sentinel run first and feed a shared data pool. MedicAI,
Navigator, SupplyMind, and VolunteerSync then run in parallel. Commander
synthesizes all four into a final, explained decision.

Full architecture: [`docs/Agent_Architecture.pdf`](docs/Agent_Architecture.pdf) ·
Workflow diagram: [`docs/Workflow_Diagram.png`](docs/Workflow_Diagram.png)

---

## Technologies Used

**Frontend:** React, Tailwind CSS, React Router, Leaflet
**Backend:** FastAPI (Python), PostgreSQL / MongoDB
**AI Orchestration:** Custom agent pipeline (LangGraph-style sequencing —
Guardian + Sentinel → parallel agents → Commander)
**Maps:** Leaflet + OpenStreetMap

---

## Installation

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

The app will be available at `http://localhost:5173` (frontend) and
`http://localhost:8000` (backend API).

---

## Screenshots

See [`screenshots/`](screenshots) for UI screenshots, and
[`docs/UI_Wireframes.pdf`](docs/UI_Wireframes.pdf) for the original wireframes.

---

## Future Scope

- Replace simulated weather/news ingestion (Sentinel) with a live API
- Replace simulated what-if engine with a real recalculating simulation model
- Full multilingual voice pipeline (Guardian) with live translation
- Multi-disaster-type support beyond flood response
- SMS/USSD fallback reporting channel for low-connectivity areas

---

## Team Members

- Srinam — Full-stack development, AI/ML, multi-agent architecture

---

## License

See [`LICENSE`](LICENSE).
